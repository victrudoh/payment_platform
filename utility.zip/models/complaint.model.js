const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const ComplaintSchema = new Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    complaint: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      required: true,
      defaultValue: "initiated",
    },
  },
  { timestamps: true }
);


module.exports = mongoose.model("Complaint", ComplaintSchema);
