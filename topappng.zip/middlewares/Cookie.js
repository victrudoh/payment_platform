// const getCookie = (cookie) => {
//   const firstHalf = cookie.trim("").split("=")[1];
//   console.log("🚀 ~ file: auth.controller.js ~ line 5 ~ firstHalf", firstHalf);
//   const otherHalf = cookie.slice(-2);
//   console.log("🚀 ~ file: auth.controller.js ~ line 7 ~ otherHalf", otherHalf);
//   const isLoggedIn = String(firstHalf + otherHalf);
//   console.log(cookie.trim().split("=")[1]);
//   return isLoggedIn;
// };

// module.exports = getCookie;
